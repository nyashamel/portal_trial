package com.example.studentportal_android.service.impl;

import com.example.studentportal_android.common.Common;
import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.domain.Role;
import com.example.studentportal_android.repository.RoleRepository;
import com.example.studentportal_android.service.api.IRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class RoleServiceImpl implements IRoleService {
    private final RoleRepository roleRepository;
@Autowired
    public RoleServiceImpl(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public Response createRole(Role role) {
        Role SavedRole = Role.builder()
                .roleName(role.getRoleName())
                .common(Common.builder()
                        .createdDate(LocalDateTime.now())
                        .build())
                .build();
        roleRepository.save(role);
        return new Response<>().buildSuccessResponse("Role Successfully created",SavedRole);
    }

    @Override
    public Response getAllRoles() {
        List<Role> roles = roleRepository.findAll();
        return new Response<>().buildSuccessResponse("Role Successfully created",roles);
    }

    @Override
    public Response<Object> updatedRoles(Long roleId, Role role) {
    //find the ID provided
        Optional<Role> optionalRole = roleRepository.findById(roleId);
        //If found then update
        if (!optionalRole.isPresent()){
            return new Response<>().buildFailedResponse("Role is not present");
        }
        Role existingRole = optionalRole.get();
        existingRole.setRoleName(role.getRoleName());

        //save
        Role updatedRole = roleRepository.save(existingRole);
        return new Response<>().buildSuccessResponse("Role successfully updated",updatedRole);
    }

    @Override
    public void deleteRole(Long roleId) {
    roleRepository.deleteById(roleId);

    }
}


