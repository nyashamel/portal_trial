package com.example.studentportal_android.controller;

import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.domain.User;
import com.example.studentportal_android.service.api.IUserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class UserController {


    private final IUserService userServiceImpl;

    public UserController(IUserService userServiceImpl) {
        this.userServiceImpl = userServiceImpl;
    }


    //Create
    @PostMapping("/create")
    public Response createUser(@RequestBody User user) {

        return userServiceImpl.createUser(user);
    }

    //read
    @GetMapping("/readUsers")
    public Response getAllUsers() {

        return (Response) userServiceImpl.getAllUsers();
    }

    //update
    @PostMapping("/updateUser/{userId}")
    public Response<Object> updateUser(@PathVariable Long userId, @RequestBody User user) {

        return userServiceImpl.updatedUser(userId, user);
    }

    //Delete
    @DeleteMapping("/deleteUser/{userId}")
    public void deleteUser(@PathVariable Long userId) {
        userServiceImpl.deleteUser(userId);
    }


}


