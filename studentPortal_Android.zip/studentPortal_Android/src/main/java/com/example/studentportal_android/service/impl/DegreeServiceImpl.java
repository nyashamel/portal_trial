package com.example.studentportal_android.service.impl;

import com.example.studentportal_android.common.Common;
import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.domain.dto.DegreeDTO;
import com.example.studentportal_android.domain.dto.UpdateDegreeDTO;
import com.example.studentportal_android.repository.DegreeRepository;
import com.example.studentportal_android.service.api.IDegreeService;
import com.example.studentportal_android.domain.Degree;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DegreeServiceImpl implements IDegreeService {

    private final DegreeRepository degreeRepository;

    public DegreeServiceImpl(DegreeRepository degreeRepository) {
        this.degreeRepository = degreeRepository;
    }

    @Override
    public Response createDegree(DegreeDTO degreeDTO) {

        Degree saveDegree = Degree.builder()
                .degreeLength(degreeDTO.getDegreeLength())
                .degreeName(degreeDTO.getDegreeName())
                .common(Common.builder()
                        .createdDate(LocalDateTime.now())
                        .createdBy(degreeDTO.getCreatedBy())
                        .build())
                .build();
        return new Response<>().buildSuccessResponse("successfully created degree",degreeRepository.save(saveDegree));


    }

    @Override
    public Response getAllDegrees() {
        List<Degree> degrees = degreeRepository.findAll();

        return new Response<>().buildSuccessResponse("degrees found",degrees);

    }

    @Override
    public Response updatedDegree(UpdateDegreeDTO updateDegreeDTO) {
        Optional<Degree> optionalDegree = degreeRepository.findById(updateDegreeDTO.getDegreeId());
        //If found update
        if (!optionalDegree.isPresent()) {
            return new Response<>().buildFailedResponse("Degree is not present");
        }
        Degree existingDegree = optionalDegree.get();
        existingDegree.setDegreeName(updateDegreeDTO.getDegreeName());
        existingDegree.setDegreeLength(updateDegreeDTO.getDegreeLength());
        existingDegree.setCommon(Common.builder()
                .lastModifiedDate(LocalDateTime.now())
                .modifiedBy(updateDegreeDTO.getModifiedBy())
                .build());
        //save
        return new Response<>().buildSuccessResponse("successfully created degree",degreeRepository.save(existingDegree));

    }


    @Override
    public void deleteDegree(Long degreeId) {
        degreeRepository.deleteById(degreeId);

    }
}
