package com.example.studentportal_android.service.impl;

import com.example.studentportal_android.common.Common;
import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.repository.FacultyRepository;
import com.example.studentportal_android.service.api.IFacultyService;
import com.example.studentportal_android.domain.Faculty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class FacultyServiceImpl implements IFacultyService {

    private final FacultyRepository facultyRepository;

    @Autowired
    public FacultyServiceImpl(FacultyRepository facultyRepository) {
        this.facultyRepository = facultyRepository;
    }

    @Override
    public Response createFaculty(Faculty faculty) {
        Faculty savefaculty = Faculty.builder()
                .facultyName(faculty.getFacultyName())
                .facultyHead(faculty.getFacultyHead())
                .common(Common.builder()
                        .createdDate(LocalDateTime.now())
                        .build())
                .build();

        facultyRepository.save(faculty);

        return new Response<>().buildSuccessResponse("Successfully created a faculty", savefaculty );
    }

    @Override
    public List<Faculty> getAllFaculties() {
        List<Faculty> getAllFaculties = facultyRepository.findAll();
        return getAllFaculties;
    }

    @Override
    public Response updatedFaculty(Long facultyId, Faculty faculty) {
        //find the ID Provided
        Optional<Faculty> optionalFaculty = facultyRepository.findById(facultyId);

        //If found then update
        if (!optionalFaculty.isPresent()){
            return  new Response<>().buildFailedResponse("Faculty is not present");
        }
        Faculty existingFaculty = optionalFaculty.get();
        existingFaculty.setFacultyName(faculty.getFacultyName());
        existingFaculty.setFacultyHead(faculty.getFacultyHead());
        existingFaculty.setDegreeId(faculty.getDegreeId());

        //save
        Faculty updatedFaculty = facultyRepository.save(existingFaculty);
        return new Response<>().buildSuccessResponse("Successfully updated faculty",updatedFaculty);
    }

    @Override
    public void deleteFaculty(Long facultyId) {
        facultyRepository.deleteById(facultyId);

    }
}
