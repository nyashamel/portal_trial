package com.example.studentportal_android.repository;

public interface RepositoryMarker {
}
