package com.example.studentportal_android.service.api;

import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.domain.Degree;
import com.example.studentportal_android.domain.dto.DegreeDTO;
import com.example.studentportal_android.domain.dto.UpdateDegreeDTO;

public interface IDegreeService {
    //Create operation

    Response createDegree(DegreeDTO degreeDTO);
    //Read Operation
    Response getAllDegrees();
    //Update Operation
   Response updatedDegree (UpdateDegreeDTO updateDegreeDTO);
    //Delete Operation
    void  deleteDegree (Long degreeId);
}
