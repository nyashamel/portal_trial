package com.example.studentportal_android.domain;

import com.example.studentportal_android.common.Common;
import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@ToString
@RequiredArgsConstructor
@Builder
@Entity
@Table(name = "users")
public class User {
    private String username;
    private String password;
    private boolean enabled;
    private String fullName;
    private String email;
    private Boolean locked;
    private Long userId;
    @Embedded
    private Common common;

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "user_Id",nullable = false)
    public Long getUserId() {
        return userId;
    }
}
