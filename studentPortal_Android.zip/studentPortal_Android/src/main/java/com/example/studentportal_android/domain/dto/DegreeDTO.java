package com.example.studentportal_android.domain.dto;

import lombok.Data;

@Data
public class DegreeDTO {

    private String degreeName;
    private String degreeLength;
    private String createdBy;

}
