package com.example.studentportal_android.domain;


import com.example.studentportal_android.common.Common;
import lombok.*;

import javax.persistence.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class Faculty {
    private String facultyName;
    private String facultyHead;
    private Long degreeId;
    private Long facultyId;

    @Embedded
    private Common common;

    public void setFacultyId(Long facultyId) {
        this.facultyId = facultyId;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "faculty_Id",nullable = false)
    public Long getFacultyId() {
        return facultyId;
    }
}
