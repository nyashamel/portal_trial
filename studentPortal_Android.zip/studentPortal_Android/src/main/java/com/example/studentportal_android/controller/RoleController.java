package com.example.studentportal_android.controller;


        import com.example.studentportal_android.common.Response;
        import com.example.studentportal_android.domain.Role;
        import com.example.studentportal_android.service.api.IRoleService;
        import lombok.RequiredArgsConstructor;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.web.bind.annotation.*;

        import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("role")
public class RoleController {
    public RoleController(IRoleService roleServiceImpl) {

        this.roleServiceImpl = roleServiceImpl;
    }

    @Autowired
    private final IRoleService roleServiceImpl;


    @PostMapping("/role")
    public Response<Object> createRole(@RequestBody Role role) {
        return roleServiceImpl.createRole(role);
    }

    @GetMapping("/readRoles")
    public List<Role> getAllUsers() {
       return roleServiceImpl.getAllRoles();
    }

    @PostMapping("/updateRoles/{roleId}")
    public Response<Object> updatedRole(@PathVariable Long roleId, @RequestBody Role role) {
      return roleServiceImpl.updatedRoles(roleId,role);
    }

    @DeleteMapping("/deleteRole/{roleId}")
    public void deleteRole(@PathVariable Long roleId) {
        roleServiceImpl.deleteRole(roleId);
    }
}