package com.example.studentportal_android.domain;

public interface EntityMarker {
}
