package com.example.studentportal_android.service.impl;

import com.example.studentportal_android.common.Common;
import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.domain.User;
import com.example.studentportal_android.repository.UserRepository;
import com.example.studentportal_android.service.api.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements IUserService {
    private final UserRepository userRepository;
@Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Response createUser(User user) {
        User savedUser = User.builder()
                .email(user.getEmail())
                .fullName(user.getFullName())
                .username(user.getUsername())
                .enabled(user.isEnabled())
                .locked(user.getLocked())
                .password(user.getPassword())
                .common(Common.builder()
                        .createdDate(LocalDateTime.now())
                        .build())
                .build();
        userRepository.save(user);
        return new Response<>().buildSuccessResponse("User Created successfully",savedUser);
    }

    @Override
    public List<User> getAllUsers() {
        List<User> getUsers = userRepository.findAll();
        return getUsers;
    }

    @Override
    public Response<Object> updatedUser(Long userId, User user) {
        //find the ID provided
        Optional<User> optionalUser = userRepository.findById(userId);

        //If found then update
        if(!optionalUser.isPresent()){
            return new Response<>().buildFailedResponse("User Not Found");
        }
        User existingUser = optionalUser.get();
        existingUser.setFullName(user.getFullName());
        existingUser.setUsername(user.getUsername());
        existingUser.setEmail(user.getEmail());
        existingUser.setPassword(user.getPassword());
        existingUser.setEnabled(user.isEnabled());
        existingUser.setLocked(user.getLocked());

        //save
        User updatedUser = userRepository.save(existingUser);
        return new Response<>().buildSuccessResponse("User updated Successfully", updatedUser);
    }

    @Override
    public void deleteUser(Long userId) {
    userRepository.deleteById(userId);

    }
}
