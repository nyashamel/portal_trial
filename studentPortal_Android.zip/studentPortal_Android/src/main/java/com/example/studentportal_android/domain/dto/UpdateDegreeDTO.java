package com.example.studentportal_android.domain.dto;

import lombok.Data;

@Data
public class UpdateDegreeDTO {
    private Long degreeId;
    private String degreeName;
    private String degreeLength;
    private String modifiedBy;
}
