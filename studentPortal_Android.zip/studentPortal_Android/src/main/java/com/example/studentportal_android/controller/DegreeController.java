package com.example.studentportal_android.controller;

import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.domain.dto.DegreeDTO;
import com.example.studentportal_android.domain.dto.UpdateDegreeDTO;
import com.example.studentportal_android.service.api.IDegreeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/degree",
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public class DegreeController {

    private final IDegreeService iDegreeService;

    public DegreeController(IDegreeService iDegreeService) {
        this.iDegreeService = iDegreeService;
    }


    @PostMapping("/create")
    public Response createDegree(@RequestBody DegreeDTO degreeDTO) {

        return iDegreeService.createDegree(degreeDTO);
    }

    @GetMapping("/read")
    public Response getAllDegrees() {
         return iDegreeService.getAllDegrees();

    }
    @PostMapping("/update")
    public Response updateDegree( @RequestBody UpdateDegreeDTO degreeDTO) {
        return iDegreeService.updatedDegree(degreeDTO);

    }
    @DeleteMapping("/delete/{degreeId}")
    public void deleteDegree(@PathVariable Long degreeId) {
        iDegreeService.deleteDegree(degreeId);
    }
}
