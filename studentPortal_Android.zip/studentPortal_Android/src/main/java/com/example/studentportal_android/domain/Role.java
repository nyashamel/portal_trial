package com.example.studentportal_android.domain;

import com.example.studentportal_android.common.Common;
import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
public class Role {
    private String roleName;
    private Long roleId;

    @Embedded
    private Common common;

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "role_Id",nullable = false)
    public Long getRoleId() {
        return roleId;
    }


}

