package com.example.studentportal_android.service.api;

import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.domain.Role;

import java.util.List;

public interface IRoleService {
    //Create operation
    Response<Object> createRole(Role role);
    //Read Operation
    Response getAllRoles();
    //Update Operation
    Response<Object> updatedRoles (Long roleId, Role role);
    //Delete Operation
    void  deleteRole (Long roleId);
}
