package com.example.studentportal_android.controller;

import com.example.studentportal_android.common.Response;
import com.example.studentportal_android.domain.Faculty;
import com.example.studentportal_android.service.api.IFacultyService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class FacultyController {
    private final IFacultyService iFacultyService;

    public FacultyController(IFacultyService iFacultyService) {
        this.iFacultyService = iFacultyService;
    }

    //Create
    @PostMapping("/faculty")
    public Response createFaculty(@RequestBody Faculty faculty){

        return iFacultyService.createFaculty(faculty);
    }
    //read
    @GetMapping("/readFaculty")
    public List<Faculty> getAllFaculties() {
        return iFacultyService.getAllFaculties();

    }
    //update
    @PostMapping("/update/{facultyId}")
    public Response updateFaculty(@PathVariable Long facultyId, @RequestBody Faculty faculty ){
      return iFacultyService.updatedFaculty(facultyId, faculty);
    }

    //Delete
    @DeleteMapping("/delete/{facultyId}")
    public void deleteFaculty(@PathVariable Long facultyId) {
        iFacultyService.deleteFaculty(facultyId);
    }

}
