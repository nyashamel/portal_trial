package com.example.studentportal_android.controller;

public interface ControllerMarker {
}
