package com.example.studentportal_android.service;

public interface ServiceMarker {
}
