package com.example.studentportal_android.domain;


import com.example.studentportal_android.common.Common;
import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
public class Degree {
    private String degreeName;
    private String degreeLength;
    private Long degreeId;
    @Embedded
    private Common common;



    public void setDegreeId(Long degreeId) {
        this.degreeId = degreeId;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "degree_Id",nullable = false)
    public Long getDegreeId() {
        return degreeId;
    }
}

